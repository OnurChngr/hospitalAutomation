﻿namespace HastaneOtomasyonu
{
    partial class SifremiUnuttum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnMailGonder = new System.Windows.Forms.Button();
            this.txtMailGönder = new System.Windows.Forms.TextBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.lblMailMesaj = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(126, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mailinizi Giriniz:";
            // 
            // btnMailGonder
            // 
            this.btnMailGonder.Location = new System.Drawing.Point(394, 155);
            this.btnMailGonder.Name = "btnMailGonder";
            this.btnMailGonder.Size = new System.Drawing.Size(118, 44);
            this.btnMailGonder.TabIndex = 1;
            this.btnMailGonder.Text = "Mail Gönder";
            this.btnMailGonder.UseVisualStyleBackColor = true;
            this.btnMailGonder.Click += new System.EventHandler(this.btnMailGonder_Click);
            // 
            // txtMailGönder
            // 
            this.txtMailGönder.Location = new System.Drawing.Point(242, 114);
            this.txtMailGönder.Name = "txtMailGönder";
            this.txtMailGönder.Size = new System.Drawing.Size(401, 22);
            this.txtMailGönder.TabIndex = 2;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(394, 218);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(118, 23);
            this.progressBar1.TabIndex = 3;
            // 
            // lblMailMesaj
            // 
            this.lblMailMesaj.AutoSize = true;
            this.lblMailMesaj.Location = new System.Drawing.Point(64, 300);
            this.lblMailMesaj.Name = "lblMailMesaj";
            this.lblMailMesaj.Size = new System.Drawing.Size(52, 16);
            this.lblMailMesaj.TabIndex = 4;
            this.lblMailMesaj.Text = "...............";
            // 
            // SifremiUnuttum
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblMailMesaj);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.txtMailGönder);
            this.Controls.Add(this.btnMailGonder);
            this.Controls.Add(this.label1);
            this.Name = "SifremiUnuttum";
            this.Text = "SifremiUnuttum";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMailGonder;
        private System.Windows.Forms.TextBox txtMailGönder;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label lblMailMesaj;
    }
}