﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HastaneOtomasyonu
{
    public partial class KullaniciIslemleri : Form
    {
        public KullaniciIslemleri()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection();     
        SqlDataReader dr;
        Kullanici k = new Kullanici();

        List<Kullanici> liste = new List<Kullanici>();

        public void temizle()
        {
            txtAd.Clear();
            txtSoyad.Clear();
            txtTc.Clear();
            txtTel.Clear();

        }

        public void listele()
        {
            liste.Clear();
            baglanti.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from kullanici";
            cmd.Connection = baglanti;
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Kullanici kullanici = new Kullanici();
                kullanici.ad = dr["ad"].ToString();               
                kullanici.soyad = dr["soyad"].ToString();
                kullanici.tc = dr["tc"].ToString();
                kullanici.tel = dr["tel"].ToString();

                liste.Add(kullanici);

            }

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = liste;
            baglanti.Close();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                Kullanici kullanici = (Kullanici)dataGridView1.SelectedRows[0].DataBoundItem;
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "delete from kullanici where kullaniciid=" + kullanici.id;
                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

            }
            else
            {
                MessageBox.Show("bir adet kayıt seçmelisiniz");
            }

            baglanti.Close();
            listele();
            temizle();



        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (txtAd.Text != "" && txtSoyad.Text != "" && txtTc.Text != "" &&txtTel.Text != "")
            {
                baglanti.Open();

                Kullanici kullanici = new Kullanici();
                kullanici.ad = dr["ad"].ToString();
                kullanici.soyad = dr["soyad"].ToString();
                kullanici.tc = dr["tc"].ToString();
                kullanici.tel = dr["tel"].ToString();
               

                liste.Add(kullanici);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into kullanici values (@p1,@p2,@p3,@p4)";
                cmd.Parameters.AddWithValue("@p1", k.ad);
                cmd.Parameters.AddWithValue("@p2", k.soyad);
                cmd.Parameters.AddWithValue("@p3", k.tc);
                cmd.Parameters.AddWithValue("@p4", k.tel);


                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

                MessageBox.Show("Kayıt Eklendi");
            }
            else
            {
                MessageBox.Show("boş alan bırakmayınız");
            }

            baglanti.Close();

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            baglanti.ConnectionString = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                Kullanici  kullanici = (Kullanici)dataGridView1.SelectedRows[0].DataBoundItem;

                txtAd.Text = kullanici.ad;
                txtSoyad.Text = kullanici.soyad;
                txtTc.Text = kullanici.tc;
                txtTel.Text = kullanici.tel;

            }
        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            listele();
            temizle();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (txtAd.Text != "" && txtSoyad.Text != "" && txtTc.Text != "" && txtTel.Text != "")
            {
                Kullanici kullanici = (Kullanici)dataGridView1.SelectedRows[0].DataBoundItem;
                txtAd.Text = kullanici.ad;
                txtSoyad.Text = kullanici.soyad;
                txtTc.Text = kullanici.tc;
                txtTel.Text = kullanici.tel;

                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update kullanici set ad=@p1,soyad=@p2,tc=@p3,tel=@p4";
                cmd.Parameters.AddWithValue("@p1", k.ad);
                cmd.Parameters.AddWithValue("@p2", k.soyad);
                cmd.Parameters.AddWithValue("@p3", k.tc);
                cmd.Parameters.AddWithValue("@p4", k.tel);



                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

                MessageBox.Show("kayıt başarıyla güncellenmiştir");

            }
            else
            {
                MessageBox.Show("Güncellemek için kayıt seçmelisiniz");
            }
            baglanti.Close();

            listele();
            temizle();
        }
    }
    
    
}
