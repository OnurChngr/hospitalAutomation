﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HastaneOtomasyonu
{
    public partial class BolumEkle : Form
    {
        public BolumEkle()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection();
        SqlDataReader dr;
        Bolum b = new Bolum();
        List<Bolum> liste = new List<Bolum>();

        public void temizle()
        {
            txtBolum.Clear();
            
        }

        public void listele()
        {
            liste.Clear();
            baglanti.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from bolum";
            cmd.Connection = baglanti;
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Bolum bolum = new Bolum();
                bolum.bolumid = dr["bolumid"].ToString();
                bolum.bolumad = dr["bolumad"].ToString();


                liste.Add(bolum);

            }

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = liste;
            baglanti.Close();
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (txtBolum.Text != "")
            {
                baglanti.Open();

                Bolum bolum = new Bolum();                
                bolum.bolumid = dr["bolumid"].ToString();
                bolum.bolumad = dr["bolumad"].ToString();


                liste.Add(bolum);
               

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into bolum values (@p1)";
                cmd.Parameters.AddWithValue("@p1", b.bolumid);
                cmd.Parameters.AddWithValue("@p2", b.bolumad);


                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

                MessageBox.Show("Kayıt Eklendi");
            }
            else
            {
                MessageBox.Show("boş alan bırakmayınız");
            }

            baglanti.Close();

        }

        private void BolumEkle_Load(object sender, EventArgs e)
        {
            baglanti.ConnectionString = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (txtBolum.Text != "")
            {
                Bolum bolum = (Bolum)dataGridView1.SelectedRows[0].DataBoundItem;
                txtBolum.Text=bolum.bolumad;

                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update bolum set bolummid=@p1,bolumad=@p2";
                cmd.Parameters.AddWithValue("@p1", b.bolumid);
                cmd.Parameters.AddWithValue("@p1", b.bolumad);


                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

                MessageBox.Show("kayıt başarıyla güncellenmiştir");

            }
            else
            {
                MessageBox.Show("Güncellemek için kayıt seçmelisiniz");
            }
            baglanti.Close();

            listele();
            temizle();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                Bolum bolum = (Bolum)dataGridView1.SelectedRows[0].DataBoundItem;
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "delete from doktor where doktorid=" + bolum.bolumid;
                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

            }
            else
            {
                MessageBox.Show("bir adet kayıt seçmelisiniz");
            }

            baglanti.Close();
            listele();
            temizle();
        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            listele();
            temizle();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                Bolum bolum = (Bolum)dataGridView1.SelectedRows[0].DataBoundItem;
                txtBolum.Text = bolum.bolumad;

            }
        }
    }
}
