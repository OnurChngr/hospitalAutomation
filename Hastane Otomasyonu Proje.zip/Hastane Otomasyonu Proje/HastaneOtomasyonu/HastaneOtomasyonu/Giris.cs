﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HastaneOtomasyonu
{
    public partial class Giris : Form
    {
        private void InitData()
        {
            if (Properties.Settings.Default.Username != string.Empty)
            {
                if (Properties.Settings.Default.Remember == true)
                {
                    txtkulad.Text = Properties.Settings.Default.Username;
                    chcRememberMe.Checked = true;
                }
                else
                {
                    txtkulad.Text = Properties.Settings.Default.Username;
                }
            }
        }

        private void SaveData()
        {
            if (chcRememberMe.Checked)
            {
                Properties.Settings.Default.Username = txtkulad.Text.Trim();
                Properties.Settings.Default.Remember = true;
                Properties.Settings.Default.Save();
            }
            else
            {
                Properties.Settings.Default.Username = "";
                Properties.Settings.Default.Remember = false;
                Properties.Settings.Default.Save();
            }
        }
        public Giris()
        {
            InitializeComponent();

            InitData();
        }

        private void btnGiriş_Click(object sender, EventArgs e)
        {
            SaveData();

            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
            con.Open();
            SqlCommand komut = new SqlCommand();
            komut.CommandText = "select * from kullanici where kulad='" + txtkulad.Text + "'and sifre='" + txtsifre.Text + "'";
            komut.Connection = con;
            SqlDataReader dr = komut.ExecuteReader();

            if (dr.HasRows)
            {
                bool adminMi;
                if (txtkulad.Text == "admin"&&txtsifre.Text=="123")
                {
                    adminMi = true;

                }
                else
                {
                    adminMi = false;
                }               

               Islemler form = new Islemler(adminMi);
                form.ShowDialog();
                

            }
            else
            {
                MessageBox.Show("hatalı kullanıcı adı veya şifre");
            }




            con.Close();
            

        }

        private void chcSifreGoster_CheckedChanged(object sender, EventArgs e)
        {
            if (chcSifreGoster.Checked)
            {
                
                txtsifre.PasswordChar = '\0';
            }
            
            else
            {
                txtsifre.PasswordChar = '*';
            }

        }

        private void lblSifreUnut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            SifremiUnuttum form = new SifremiUnuttum();
            form.Show();



        }
    }
}
