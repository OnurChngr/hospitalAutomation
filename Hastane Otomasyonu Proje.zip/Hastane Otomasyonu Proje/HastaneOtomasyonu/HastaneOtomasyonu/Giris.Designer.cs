﻿
namespace HastaneOtomasyonu
{
    partial class Giris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblSifreUnut = new System.Windows.Forms.LinkLabel();
            this.chcSifreGoster = new System.Windows.Forms.CheckBox();
            this.chcRememberMe = new System.Windows.Forms.CheckBox();
            this.txtsifre = new System.Windows.Forms.TextBox();
            this.txtkulad = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGiriş = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblSifreUnut);
            this.groupBox1.Controls.Add(this.chcSifreGoster);
            this.groupBox1.Controls.Add(this.chcRememberMe);
            this.groupBox1.Controls.Add(this.txtsifre);
            this.groupBox1.Controls.Add(this.txtkulad);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnGiriş);
            this.groupBox1.Location = new System.Drawing.Point(249, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(239, 263);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kullanıcı Bilgileri";
            // 
            // lblSifreUnut
            // 
            this.lblSifreUnut.AutoSize = true;
            this.lblSifreUnut.LinkColor = System.Drawing.Color.Teal;
            this.lblSifreUnut.Location = new System.Drawing.Point(77, 172);
            this.lblSifreUnut.Name = "lblSifreUnut";
            this.lblSifreUnut.Size = new System.Drawing.Size(99, 16);
            this.lblSifreUnut.TabIndex = 12;
            this.lblSifreUnut.TabStop = true;
            this.lblSifreUnut.Text = "Şifremi Unuttum";
            this.lblSifreUnut.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblSifreUnut_LinkClicked);
            // 
            // chcSifreGoster
            // 
            this.chcSifreGoster.AutoSize = true;
            this.chcSifreGoster.Location = new System.Drawing.Point(125, 132);
            this.chcSifreGoster.Name = "chcSifreGoster";
            this.chcSifreGoster.Size = new System.Drawing.Size(109, 20);
            this.chcSifreGoster.TabIndex = 11;
            this.chcSifreGoster.Text = "Şifreyi Göster";
            this.chcSifreGoster.UseVisualStyleBackColor = true;
            this.chcSifreGoster.CheckedChanged += new System.EventHandler(this.chcSifreGoster_CheckedChanged);
            // 
            // chcRememberMe
            // 
            this.chcRememberMe.AutoSize = true;
            this.chcRememberMe.Location = new System.Drawing.Point(6, 132);
            this.chcRememberMe.Name = "chcRememberMe";
            this.chcRememberMe.Size = new System.Drawing.Size(98, 20);
            this.chcRememberMe.TabIndex = 10;
            this.chcRememberMe.Text = "Beni Hatırla";
            this.chcRememberMe.UseVisualStyleBackColor = true;
            // 
            // txtsifre
            // 
            this.txtsifre.Location = new System.Drawing.Point(125, 87);
            this.txtsifre.Name = "txtsifre";
            this.txtsifre.Size = new System.Drawing.Size(100, 22);
            this.txtsifre.TabIndex = 9;
            // 
            // txtkulad
            // 
            this.txtkulad.Location = new System.Drawing.Point(125, 41);
            this.txtkulad.Name = "txtkulad";
            this.txtkulad.Size = new System.Drawing.Size(100, 22);
            this.txtkulad.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Şifre:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Kullanıcı Adı:";
            // 
            // btnGiriş
            // 
            this.btnGiriş.Location = new System.Drawing.Point(73, 212);
            this.btnGiriş.Name = "btnGiriş";
            this.btnGiriş.Size = new System.Drawing.Size(108, 45);
            this.btnGiriş.TabIndex = 5;
            this.btnGiriş.Text = "Giriş";
            this.btnGiriş.UseVisualStyleBackColor = true;
            this.btnGiriş.Click += new System.EventHandler(this.btnGiriş_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(746, 424);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Kullanıcı Bilgileri";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtsifre;
        private System.Windows.Forms.TextBox txtkulad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGiriş;
        private System.Windows.Forms.CheckBox chcRememberMe;
        private System.Windows.Forms.CheckBox chcSifreGoster;
        private System.Windows.Forms.LinkLabel lblSifreUnut;
    }
}

