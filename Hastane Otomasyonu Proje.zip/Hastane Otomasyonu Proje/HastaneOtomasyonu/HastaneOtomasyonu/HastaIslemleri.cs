﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HastaneOtomasyonu
{
    public partial class HastaIslemleri : Form
    {
        public HastaIslemleri(bool adminMi)
        {
            InitializeComponent();

            if (adminMi==false)
            {
                btnKaydet.Visible = false;
                btnSil.Visible = false;
                btnGüncelle.Visible = false;

            }
        }


        SqlConnection baglanti = new SqlConnection();
        
        SqlDataReader dr;
        Hasta h = new Hasta();
        
        List<Hasta> liste = new List<Hasta>();

        public void temizle()
        {
            txtHastaAd.Clear();
            txtHastaSoyad.Clear();
            txtTc.Clear();
            cmbhastalik.Items.Clear();
            cmbSehir.Items.Clear();
            cmbDoktor.Items.Clear();
            cmbBolum.Items.Clear();

        }

        public void listele()
        {
            liste.Clear();
            baglanti.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from hasta";
            cmd.Connection = baglanti;
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Hasta hasta = new Hasta();
                hasta.ad = dr["hastaAd"].ToString();
                hasta.soyad = dr["hastaSoyad"].ToString();
                hasta.tc = dr["tc"].ToString();
                hasta.hastalik = dr["hastalikid"].ToString();
                hasta.sehir = dr["sehirid"].ToString();
                hasta.doktor = dr["doktorid"].ToString();
                hasta.bolum = dr["bolumid"].ToString();

                liste.Add(hasta);

            }

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = liste;
            baglanti.Close();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count==1)
            {
                Hasta hasta = (Hasta)dataGridView1.SelectedRows[0].DataBoundItem;
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "delete from hasta where hastaid=" + hasta.id;
                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

            }
            else
            {
                MessageBox.Show("bir adet kayıt seçmelisiniz");
            }

            baglanti.Close();
            listele();
            temizle();         
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (txtHastaAd.Text!=""&& txtHastaSoyad.Text!=""&& txtTc.Text!=""&& cmbBolum.Text!=""&& cmbDoktor.Text!=""&& cmbhastalik.Text!=""&& cmbSehir.Text!="")
            {
                baglanti.Open();

                Hasta hasta = new Hasta();
                hasta.ad = dr["hastaAd"].ToString();
                hasta.soyad = dr["hastaSoyad"].ToString();
                hasta.tc = dr["tc"].ToString();
                hasta.hastalik = dr["hastalikid"].ToString();
                hasta.sehir = dr["sehirid"].ToString();
                hasta.doktor = dr["doktorid"].ToString();
                hasta.bolum = dr["bolumid"].ToString();

                liste.Add(hasta);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into hasta values (@p1,@p2,@p3,@p4,@p5,@p6,@p7)";
                cmd.Parameters.AddWithValue("@p1", h.ad);
                cmd.Parameters.AddWithValue("@p2", h.soyad);
                cmd.Parameters.AddWithValue("@p3", h.tc);
                cmd.Parameters.AddWithValue("@p4", h.hastalik);
                cmd.Parameters.AddWithValue("@p5", h.sehir);
                cmd.Parameters.AddWithValue("@p6", h.doktor);
                cmd.Parameters.AddWithValue("@p7", h.bolum);

                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

                MessageBox.Show("Kayıt Eklendi");
            }
            else
            {
                MessageBox.Show("boş alan bırakmayınız");
            }
                       
            baglanti.Close();         

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            baglanti.ConnectionString = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                Hasta hasta = (Hasta)dataGridView1.SelectedRows[0].DataBoundItem;

                txtHastaAd.Text = hasta.ad;
                txtHastaSoyad.Text = hasta.soyad;
                txtTc.Text=hasta.tc;
                cmbhastalik.Text = hasta.hastalik;
                cmbSehir.Text = hasta.sehir;
                cmbDoktor.Text = hasta.doktor;
                cmbBolum.Text = hasta.bolum;

            }

        }

        private void btnList_Click(object sender, EventArgs e)
        {
            listele();
            temizle();
        }

        private void btnGüncelle_Click(object sender, EventArgs e)
        {
            if (txtHastaAd.Text != "" && txtHastaSoyad.Text != "" && txtTc.Text != "" && cmbBolum.Text != "" && cmbDoktor.Text != "" && cmbhastalik.Text != "" && cmbSehir.Text != "")
            {
                Hasta hasta = (Hasta)dataGridView1.SelectedRows[0].DataBoundItem;
                txtHastaAd.Text = hasta.ad;
                txtHastaSoyad.Text = hasta.soyad;
                txtTc.Text = hasta.tc;
                cmbhastalik.Text = hasta.hastalik;
                cmbSehir.Text = hasta.sehir;
                cmbDoktor.Text = hasta.doktor;
                cmbBolum.Text = hasta.bolum;

                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update hasta set hastaAd=@p1,hastaSoyad=@p2,tc=@p3,hastalikid=@p4,sehirid=@p5,doktorid=@p6,bolumid=@p7";
                cmd.Parameters.AddWithValue("@p1", h.ad);
                cmd.Parameters.AddWithValue("@p2", h.soyad);
                cmd.Parameters.AddWithValue("@p3", h.tc);
                cmd.Parameters.AddWithValue("@p4", h.hastalik);
                cmd.Parameters.AddWithValue("@p5", h.sehir);
                cmd.Parameters.AddWithValue("@p6", h.doktor);
                cmd.Parameters.AddWithValue("@p7", h.bolum);

                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

                MessageBox.Show("kayıt başarıyla güncellenmiştir");

            }
            else
            {
                MessageBox.Show("Güncellemek için kayıt seçmelisiniz");
            }
            baglanti.Close();

            listele();
            temizle();
        }

        
    }
}
