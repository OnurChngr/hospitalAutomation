﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HastaneOtomasyonu
{
    internal class Hasta
    {
        public int id { get; set; }
        public string ad { get; set; }
        public string soyad { get; set; }
        public string tc { get; set; }
        public string hastalik { get; set; }
        public string sehir { get; set; }
        public string doktor { get; set; }
        public string bolum { get; set; }

    }
}
