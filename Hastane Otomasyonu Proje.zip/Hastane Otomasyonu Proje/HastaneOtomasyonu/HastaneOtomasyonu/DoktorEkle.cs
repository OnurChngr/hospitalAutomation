﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HastaneOtomasyonu
{
    public partial class DoktorEkle : Form
    {
        public DoktorEkle()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection();       
        SqlDataReader dr;
        Doktor d = new Doktor();

        List<Doktor> liste = new List<Doktor>();

        public void temizle()
        {
            txtAd.Clear();
            txtSoyad.Clear();
            cmbBolum.Items.Clear();
        }

        public void listele()
        {
            liste.Clear();
            baglanti.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from doktor";
            cmd.Connection = baglanti;
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Doktor doktor = new Doktor();
                doktor.ad = dr["doktorAd"].ToString();
                doktor.soyad = dr["doktorSoyad"].ToString();               
                doktor.bolum = dr["bolumid"].ToString();

                liste.Add(doktor);

            }

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = liste;
            baglanti.Close();
        }       

        private void YoneticiIslemleri_Load(object sender, EventArgs e)
        {
            baglanti.ConnectionString = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                Doktor doktor = (Doktor)dataGridView1.SelectedRows[0].DataBoundItem;

                txtAd.Text = doktor.ad;
                txtSoyad.Text = doktor.soyad;               
                cmbBolum.Text = doktor.bolum;

            }
        }
       
        private void btnKaydet_Click_1(object sender, EventArgs e)
        {
            if (txtAd.Text != "" && txtSoyad.Text != "" && cmbBolum.Text != "")
            {
                baglanti.Open();

                Doktor doktor = new Doktor();
                doktor.ad = dr["doktorAd"].ToString();
                doktor.soyad = dr["doktorSoyad"].ToString();
                doktor.bolum = dr["bolumid"].ToString();

                liste.Add(doktor);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into doktor values (@p1,@p2,@p3)";
                cmd.Parameters.AddWithValue("@p1", d.ad);
                cmd.Parameters.AddWithValue("@p2", d.soyad);
                cmd.Parameters.AddWithValue("@p3", d.bolum);

                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

                MessageBox.Show("Kayıt Eklendi");
            }
            else
            {
                MessageBox.Show("boş alan bırakmayınız");
            }

            baglanti.Close();
        }

        

        private void btnGuncelle_Click_1(object sender, EventArgs e)
        {
            if (txtAd.Text != "" && txtSoyad.Text != "" && cmbBolum.Text != "")
            {
                Doktor doktor = (Doktor)dataGridView1.SelectedRows[0].DataBoundItem;
                txtAd.Text = doktor.ad;
                txtSoyad.Text = doktor.soyad;
                cmbBolum.Text = doktor.bolum;

                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update doktor set doktorAd=@p1,doktorSoyad=@p2,bolumid=@p3";
                cmd.Parameters.AddWithValue("@p1", d.ad);
                cmd.Parameters.AddWithValue("@p2", d.soyad);
                cmd.Parameters.AddWithValue("@p3", d.bolum);

                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

                MessageBox.Show("kayıt başarıyla güncellenmiştir");

            }
            else
            {
                MessageBox.Show("Güncellemek için kayıt seçmelisiniz");
            }
            baglanti.Close();

            listele();
            temizle();
        }

        private void btnSil_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                Doktor doktor = (Doktor)dataGridView1.SelectedRows[0].DataBoundItem;
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "delete from doktor where doktorid=" + doktor.id;
                cmd.Connection = baglanti;
                cmd.ExecuteNonQuery();

            }
            else
            {
                MessageBox.Show("bir adet kayıt seçmelisiniz");
            }

            baglanti.Close();
            listele();
            temizle();
        }

        private void btnList_Click_1(object sender, EventArgs e)
        {
            listele();
            temizle();
        }

        
    }
}
