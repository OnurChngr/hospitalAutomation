﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastaneOtomasyonu
{
    public partial class Islemler : Form
    {
        public Islemler(bool adminMi)
        {
            InitializeComponent();

            if (adminMi == false)
            {
                btnKulİslem.Visible = false;
                btnYonetİslem.Visible = false;              
                
            }
        }

        private void btnKulİslem_Click(object sender, EventArgs e)
        {
            KullaniciIslemleri form4 = new KullaniciIslemleri();
            form4.Show();
            
        }

        private void btnHastaİslem_Click(object sender, EventArgs e)
        {
            HastaIslemleri hastaIslem = new HastaIslemleri(true);
            hastaIslem.Show();
            
        }

        private void btnYonetİslem_Click(object sender, EventArgs e)
        {
            Yonetici yonet=new Yonetici(); 
            yonet.Show();
            

        }
        
    }
}
