﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HastaneOtomasyonu
{
    internal class Doktor
    {
        public int id { get; set; }
        public string ad { get; set; }
        public string soyad { get; set; }
        public string bolum { get; set; }
    }
}
