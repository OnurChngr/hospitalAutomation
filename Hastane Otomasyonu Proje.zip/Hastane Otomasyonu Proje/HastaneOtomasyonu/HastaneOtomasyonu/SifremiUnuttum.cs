﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Configuration;

namespace HastaneOtomasyonu
{
    public partial class SifremiUnuttum : Form
    {
        public SifremiUnuttum()
        {
            InitializeComponent();
        }

        public bool MailGonder(string konu,string icerik)
        {
            MailMessage eposta=new MailMessage();
            eposta.From= new MailAddress("mail adresiniz.");
            eposta.To.Add(txtMailGönder.Text);

            eposta.Subject = konu;
            eposta.Body = icerik;

            SmtpClient smtp = new SmtpClient();
            smtp.Credentials = new System.Net.NetworkCredential("Mail Adresiniz","Mail şifreniz");
            smtp.Port = 587;
            smtp.Host = "smtp.outlook.com";
            smtp.EnableSsl = true;
            smtp.Send(eposta);
            object userState = true;
            bool cmd = true;

            try
            {
                smtp.SendAsync(eposta,(object)eposta);

            }
            catch (SmtpException ex)
            {

                cmd= false;
                MessageBox.Show(ex.Message);
            }
            return cmd;



        }

        string sifre;
        private void btnMailGonder_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
                if (con.State==ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select * from hasta where mail='"+txtMailGönder+"'";
                cmd.Connection = con;
                SqlDataReader dr=cmd.ExecuteReader();
                if (dr.Read())
                {
                    sifre = dr["sifre"].ToString();

                    lblMailMesaj.Visible=true;
                    lblMailMesaj.ForeColor=Color.Green;
                    lblMailMesaj.Text="Girmiş Olduğunuz Bilgiler Doğrulandı,Şifreniz Mail OLarak Gönderildi";

                    progressBar1.Visible=true;
                    progressBar1.Maximum = 900000;
                    progressBar1.Minimum = 90;

                    for (int i = 90; i < 900000; i++)
                    {
                        progressBar1.Value = i;
                    }
                    MailGonder("Şifre Hatırlatma","Şifreniz"+sifre);
                    con.Close();
                }

                else
                {
                    lblMailMesaj.Visible = true;
                    lblMailMesaj.ForeColor = Color.Red;
                    lblMailMesaj.Text = "Girmiş Olduğunuz Bilgiler Yanlış,Tekrar deneyiniz!!!";
                }


                


            }
            catch (Exception)
            {
                lblMailMesaj.Visible = true;
                lblMailMesaj.ForeColor = Color.Red;
                lblMailMesaj.Text = "Mail Gönderilemedi";

            }

        }
    }
}
